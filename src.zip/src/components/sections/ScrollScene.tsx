"use client";

import { useEffect, useRef, useState } from "react";
import VortexBackground from "@/components/Shader/VortexBackground";

export default function ScrollScene() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const max = document.body.scrollHeight - window.innerHeight;
      const p = window.scrollY / max;
      setProgress(p);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // 🎥 cinematic mapping
  const heroOpacity = Math.max(1 - progress * 2, 0);
  const heroScale = Math.max(1 - progress * 0.3, 0.9);

  const secondOpacity = Math.min(progress * 3, 1);
  const secondY = Math.max(100 - progress * 200, 0);

  return (
    <div className="relative w-full">

      {/* 🌌 GLOBAL BACKGROUND */}
      <div className="fixed inset-0">
        <VortexBackground />
      </div>

      {/* 🎬 HERO SCENE */}
      <section
        className="h-screen flex items-center justify-center text-white"
        style={{
          opacity: heroOpacity,
          transform: `scale(${heroScale})`,
        }}
      >
        <div className="text-center">
          <h1 className="text-6xl font-bold">RUNBOX</h1>
          <p className="opacity-70 mt-4">Build. Animate. Launch.</p>
        </div>
      </section>

      {/* 🌟 NEXT SCENE */}
      <section
        className="h-screen flex items-center justify-center text-white"
        style={{
          opacity: secondOpacity,
          transform: `translateY(${secondY}px)`,
        }}
      >
        <div className="text-center">
          <h2 className="text-5xl font-bold">Fast. Modern. Scalable.</h2>
          <p className="opacity-70 mt-4">
            Every interaction feels cinematic.
          </p>
        </div>
      </section>

    </div>
  );
}