export const CURSOR = {
  DOT_SIZE: 8,
  HOVER_SCALE: 2.5,

  Z_DOT: 99999,
} as const;