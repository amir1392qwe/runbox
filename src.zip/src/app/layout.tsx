import type { Metadata } from "next";
import { Geist } from "next/font/google";

import "./globals.css";
import Providers from "@/components/providers/Providers";

const geist = Geist({
  subsets: ["latin"],
  variable: "--font-geist",
});

export const metadata: Metadata = {
  title: {
    default: "RUNBOX",
    template: "%s | RUNBOX",
  },
  description: "Premium Gaming Experience",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${geist.variable} antialiased bg-[#050505] text-white`}>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}