export const stats = [
  {
    id: 1,
    value: 2.4,
    decimals: 1,
    suffix: "M",
    label: "Players Worldwide",
  },
  {
    id: 2,
    value: 150,
    decimals: 0,
    suffix: "+",
    label: "Games Delivered",
  },
  {
    id: 3,
    value: 4.9,
    decimals: 1,
    suffix: "/5",
    label: "Average Rating",
  },
  {
    id: 4,
    value: 24,
    decimals: 0,
    suffix: "/7",
    label: "Support Available",
  },
];