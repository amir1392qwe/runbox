export const services = [
  {
    id: 1,
    title: "Creative Development",
    description:
      "Immersive digital experiences powered by modern web technologies.",
    accent: "from-violet-500 to-fuchsia-500",
  },
  {
    id: 2,
    title: "Interactive Design",
    description:
      "Motion-first interfaces crafted with attention to every detail.",
    accent: "from-cyan-500 to-blue-500",
  },
  {
    id: 3,
    title: "Realtime Experiences",
    description:
      "Three.js, shaders and high-performance animations for premium products.",
    accent: "from-emerald-400 to-cyan-500",
  },
  {
    id: 4,
    title: "Brand Systems",
    description:
      "Scalable design systems that stay consistent across every platform.",
    accent: "from-orange-500 to-pink-500",
  },
];