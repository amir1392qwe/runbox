export interface CursorRefs {
  dot: HTMLDivElement | null;
  ring: HTMLDivElement | null;
  label: HTMLDivElement | null;
}

export interface CursorPosition {
  x: number;
  y: number;
}