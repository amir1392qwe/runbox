export const footerLinks = [
  {
    title: "Home",
    href: "/",
  },
  {
    title: "Featured",
    href: "#featured",
  },
  {
    title: "Services",
    href: "#services",
  },
  {
    title: "Showcase",
    href: "#showcase",
  },
  {
    title: "Contact",
    href: "#contact",
  },
];

export const socials = [
  {
    title: "GitHub",
    href: "#",
  },
  {
    title: "LinkedIn",
    href: "#",
  },
  {
    title: "Instagram",
    href: "#",
  },
];