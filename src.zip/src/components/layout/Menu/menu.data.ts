export const menuItems = [
  { title: "HOME", href: "/" },
  { title: "GAMES", href: "/games" },
  { title: "COMMUNITY", href: "/community" },
  { title: "ABOUT", href: "/about" },
  { title: "CONTACT", href: "/contact" },
];