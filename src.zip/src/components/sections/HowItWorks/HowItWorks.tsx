"use client";

import Container from "@/components/ui/Container";
import StepsList from "./StepsList";

export default function HowItWorks() {
  return (
    <section className="relative bg-black py-40">
      <Container>
        <div className="mb-24 max-w-3xl">
          <p className="mb-4 text-sm uppercase tracking-[0.45em] text-violet-400">
            Process
          </p>

          <h2 className="text-6xl font-black leading-none">
            HOW WE
            <br />
            WORK
          </h2>

          <p className="mt-8 text-lg leading-8 text-neutral-400">
            A clear, collaborative process from first conversation to launch
            day.
          </p>
        </div>

        <StepsList />
      </Container>
    </section>
  );
}