"use client";

import Container from "@/components/ui/Container";
import ShowcaseList from "./ShowcaseList";

export default function Showcase() {
  return (
    <section
      id="showcase"
      className="relative overflow-hidden bg-black py-40"
    >
      <Container>
        <div className="mb-24 max-w-3xl">
          <p className="mb-4 text-sm uppercase tracking-[0.45em] text-violet-400">
            Showcase
          </p>ًَ

          <h2 className="text-6xl font-black leading-none">
            FEATURED
            <br />
            PROJECTS
          </h2>

          <p className="mt-8 text-lg leading-8 text-neutral-400">
            A selection of interactive experiences designed with motion,
            performance and immersive storytelling at the center.
          </p>
        </div>

        <ShowcaseList />
      </Container>
    </section>
  );
}