export const steps = [
  {
    id: 1,
    title: "Share Your Vision",
    description:
      "Tell us about your project, goals and the experience you want to create.",
  },
  {
    id: 2,
    title: "We Design & Prototype",
    description:
      "Our team crafts the visual direction and interactive prototypes for your review.",
  },
  {
    id: 3,
    title: "Build With Motion & Code",
    description:
      "We bring the design to life with fluid animation and production-grade code.",
  },
  {
    id: 4,
    title: "Launch & Scale",
    description:
      "Your product goes live, and we keep refining it as your audience grows.",
  },
];