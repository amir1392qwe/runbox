export const cta = {
  title: "LET'S BUILD SOMETHING INCREDIBLE",
  description:
    "We create premium digital experiences with cutting-edge technologies, smooth motion and immersive interactions.",
  button: "Start Your Project",
};