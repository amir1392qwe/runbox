"use client";

import { useRef } from "react";
import gsap from "gsap";
import { useGSAP } from "@gsap/react";

import Container from "@/components/ui/Container";

import MenuFooter from "./MenuFooter";
import MenuItem from "./MenuItem";
import { menuItems } from "./menu.data";

interface MenuContentProps {
  open: boolean;
}

export default function MenuContent({ open }: MenuContentProps) {
  const listRef = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      if (!listRef.current) return;

      if (open) {
        gsap.fromTo(
          listRef.current.children,
          { y: 60, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.7,
            stagger: 0.08,
            ease: "power3.out",
            delay: 0.25,
          }
        );
      } else {
        gsap.set(listRef.current.children, { y: 60, opacity: 0 });
      }
    },
    { dependencies: [open] }
  );

  return (
    <Container className="flex h-full items-center">
      <div ref={listRef} className="mt-24 w-full lg:mt-32">
        {menuItems.map((item) => (
          <MenuItem
            key={item.title}
            title={item.title}
            href={item.href}
          />
        ))}

        <MenuFooter />
      </div>
    </Container>
  );
}