export const games = [
  {
    id: 1,
    title: "CYBER STRIKE",
    category: "Action",
    image: "/images/games/game1.jpg",
  },
  {
    id: 2,
    title: "SHADOW LEGION",
    category: "RPG",
    image: "/images/games/game2.jpg",
  },
  {
    id: 3,
    title: "VOID RACERS",
    category: "Racing",
    image: "/images/games/game3.jpg",
  },
];