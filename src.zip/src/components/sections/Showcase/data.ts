export const showcase = [
  {
    id: 1,
    title: "Cyber Runner",
    category: "Game Website",
    image: "/images/showcase-1.jpg",
  },
  {
    id: 2,
    title: "Neon District",
    category: "Interactive Experience",
    image: "/images/showcase-2.jpg",
  },
  {
    id: 3,
    title: "Space Arena",
    category: "3D Landing Page",
    image: "/images/showcase-3.jpg",
  },
];