import Menu from "@/components/layout/Menu";
import Hero from "@/components/sections/Hero";
import Stats from "@/components/sections/Stats/Stats";
import FeaturedGames from "@/components/sections/FeaturedGames";
import ScrollScene from "@/components/sections/ScrollScene";
import Services from "@/components/sections/Services";
import HowItWorks from "@/components/sections/HowItWorks/HowItWorks";
import Showcase from "@/components/sections/Showcase";
import CTA from "@/components/sections/CTA/";
import Footer from "@/components/sections/Footer/Footer";

export default function Home() {
  return (
    <>
      <Menu />
      <Hero />
      <Stats />
      <FeaturedGames />
      <ScrollScene />
      <Services />
      <HowItWorks />
      <Showcase />
      <CTA />
      <Footer />
    </>
  );
}